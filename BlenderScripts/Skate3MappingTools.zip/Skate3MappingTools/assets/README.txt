Place your reference.glb in this folder with the exact filename 'reference.glb'. It will auto-load into the scene on Blender startup when the add-on is enabled.
